/* Design: Compressed Semantic Lattice
 * - Vertical scroll presentation with sticky Braille navigation
 * - Single column (max-width 800px) offset 20% from left
 * - Dot matrix background, sharp rectangles, minimal motion
 * - Semantic color coding: blue (continuous), amber (discrete), emerald (convergence), rose (transitions)
 */

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Menu, X } from "lucide-react";

export default function Home() {
  const [activeSection, setActiveSection] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll("[data-section]");
      let current = 0;
      
      sections.forEach((section, index) => {
        const rect = section.getBoundingClientRect();
        if (rect.top <= window.innerHeight / 2 && rect.bottom >= window.innerHeight / 2) {
          current = index;
        }
      });
      
      setActiveSection(current);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (index: number) => {
    const section = document.querySelector(`[data-section="${index}"]`);
    section?.scrollIntoView({ behavior: "smooth", block: "center" });
  };

  const sections = [
    { id: 0, braille: "⠁", title: "Title" },
    { id: 1, braille: "⠃", title: "Question" },
    { id: 2, braille: "⠉", title: "Core Idea" },
    { id: 3, braille: "⠙", title: "Architecture" },
    { id: 4, braille: "⠑", title: "Physics" },
    { id: 5, braille: "⠋", title: "Phase Transition" },
    { id: 6, braille: "⠛", title: "Braille Lattice" },
    { id: 7, braille: "⠓", title: "Power of Lattice" },
    { id: 8, braille: "⠊", title: "AGI Blueprint" },
    { id: 9, braille: "⠚", title: "Conclusion" },
    { id: 10, braille: "⠅", title: "Next Steps" },
  ];

  return (
    <div className="min-h-screen bg-background dot-matrix">
      {/* Mobile Menu Button */}
      <button
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        className="fixed top-6 right-6 z-50 lg:hidden w-12 h-12 flex items-center justify-center border border-border bg-background hover:border-accent transition-colors"
      >
        {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Mobile Navigation Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 bg-background/95 z-40 lg:hidden flex items-center justify-center">
          <div className="grid grid-cols-3 gap-4 p-8">
            {sections.map((section) => (
              <button
                key={section.id}
                onClick={() => {
                  scrollToSection(section.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-16 h-16 flex flex-col items-center justify-center text-2xl font-mono transition-all duration-200 border ${
                  activeSection === section.id
                    ? "border-accent text-accent bg-accent/10"
                    : "border-border text-muted-foreground hover:border-primary hover:text-primary"
                }`}
              >
                <span>{section.braille}</span>
                <span className="text-xs mt-1">{section.title}</span>
              </button>
            ))}
          </div>
        </div>
      )}
      {/* Sticky Braille Navigation */}
      <nav className="fixed left-8 top-1/2 -translate-y-1/2 z-50 hidden lg:block">
        <div className="flex flex-col gap-4">
          {sections.map((section) => (
            <button
              key={section.id}
              onClick={() => scrollToSection(section.id)}
              className={`w-12 h-12 flex items-center justify-center text-2xl font-mono transition-all duration-200 border ${
                activeSection === section.id
                  ? "border-accent text-accent bg-accent/10"
                  : "border-border text-muted-foreground hover:border-primary hover:text-primary"
              }`}
              title={section.title}
            >
              {section.braille}
            </button>
          ))}
        </div>
      </nav>

      {/* Main Content */}
      <main className="ml-0 lg:ml-32 max-w-4xl mx-auto px-6 py-20">
        {/* Section 0: Title */}
        <section data-section="0" className="min-h-screen flex flex-col justify-center fade-in">
          <div className="space-y-8">
            <div className="border border-border p-1 inline-block">
              <img
                src="https://private-us-east-1.manuscdn.com/sessionFile/RoQdmlQ1OcvZyhofKvZMQu/sandbox/s01YdWVmyEK5z645Z4vVor-img-1_1770695850000_na1fn_aGVyby1zZW1hbnRpYy1zcGFjZQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUm9RZG1sUTFPY3ZaeWhvZkt2Wk1RdS9zYW5kYm94L3MwMVlkV1ZteUVLNXo2NDVaNHZWb3ItaW1nLTFfMTc3MDY5NTg1MDAwMF9uYTFmbl9hR1Z5YnkxelpXMWhiblJwWXkxemNHRmpaUS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=PX9i4Cz6DzkTRXQHe4cRMxe-VM700rNk9YQE3y8l9eOpQruApnqkP2NYPKkj~IGVsEJsoA6onZOTwDKVqyxiS0M-wRcs7tRQq8ykuETpGncpuHKtHz4AEutMvgeMC5Bsv2-M7qkRvxbPeKWz9aNATJEw-flx8Kroi9mYkRvH89lrL4hLlsFvildQZx4bg3Jl993QUJPCk70MvGEuWkB551Jq4ZJ5-33P6LGxDIvz6bpmNLBOh5SAwpMwr1AHrj-JDzWFrwZCrw6g8oGct8Lmbo6u5sS08WeZzd~NZ3qoo0WQEekNSGLZCm4s61wyPyO2jOxmXrSzXDEqH5OxAMQaAw__"
                alt="Semantic space visualization"
                className="w-full h-auto"
              />
            </div>
            <h1 className="text-5xl lg:text-7xl leading-tight">
              Gods as Centroids
            </h1>
            <p className="text-2xl lg:text-3xl text-muted-foreground font-mono">
              A Mathematical Blueprint for Semantic Compression
            </p>
            <p className="text-lg text-muted-foreground max-w-2xl leading-relaxed">
              How a 2026 paper on religious evolution provides a rigorous, testable framework for AGI as recursive semantic compression.
            </p>
            <div className="flex gap-4 pt-4">
              <Button 
                onClick={() => scrollToSection(1)}
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Begin Presentation
              </Button>
              <Button 
                variant="outline"
                onClick={() => window.open("https://elevate-foundry.github.io/gods-as-centroids", "_blank")}
              >
                Read Original Paper
              </Button>
            </div>
          </div>
        </section>

        {/* Section 1: The Question */}
        <section data-section="1" className="min-h-screen flex flex-col justify-center py-20 fade-in">
          <Card className="border border-border bg-card p-8 lg:p-12">
            <h2 className="text-4xl lg:text-5xl mb-8">The Question That Changes Everything</h2>
            <div className="space-y-6 text-lg leading-relaxed">
              <p className="text-3xl font-mono text-accent">
                What if gods were mathematical objects?
              </p>
              <p>
                What if the most powerful, abstract concepts that have guided humanity for millennia weren't just stories, but <strong>emergent properties of a complex system</strong>? What if they could be described with the rigor of physics, and predicted with the precision of a mathematical model?
              </p>
              <p>
                Today, we explore a paper that does exactly that: <strong>"Gods as Centroids: A Generative Vector-Space Model of Religious Evolution"</strong> by Ryan Barrett. While framed as computational social science, it provides something far more valuable: a concrete, validated blueprint for AGI as recursive semantic compression.
              </p>
            </div>
          </Card>
        </section>

        {/* Section 2: Core Idea */}
        <section data-section="2" className="min-h-screen flex flex-col justify-center py-20 fade-in">
          <h2 className="text-4xl lg:text-5xl mb-8">The Core Idea: Gods as Emergent Centroids</h2>
          <div className="border border-border p-1 mb-8">
            <img
              src="https://private-us-east-1.manuscdn.com/sessionFile/RoQdmlQ1OcvZyhofKvZMQu/sandbox/s01YdWVmyEK5z645Z4vVor-img-1_1770695850000_na1fn_aGVyby1zZW1hbnRpYy1zcGFjZQ.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUm9RZG1sUTFPY3ZaeWhvZkt2Wk1RdS9zYW5kYm94L3MwMVlkV1ZteUVLNXo2NDVaNHZWb3ItaW1nLTFfMTc3MDY5NTg1MDAwMF9uYTFmbl9hR1Z5YnkxelpXMWhiblJwWXkxemNHRmpaUS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=PX9i4Cz6DzkTRXQHe4cRMxe-VM700rNk9YQE3y8l9eOpQruApnqkP2NYPKkj~IGVsEJsoA6onZOTwDKVqyxiS0M-wRcs7tRQq8ykuETpGncpuHKtHz4AEutMvgeMC5Bsv2-M7qkRvxbPeKWz9aNATJEw-flx8Kroi9mYkRvH89lrL4hLlsFvildQZx4bg3Jl993QUJPCk70MvGEuWkB551Jq4ZJ5-33P6LGxDIvz6bpmNLBOh5SAwpMwr1AHrj-JDzWFrwZCrw6g8oGct8Lmbo6u5sS08WeZzd~NZ3qoo0WQEekNSGLZCm4s61wyPyO2jOxmXrSzXDEqH5OxAMQaAw__"
              alt="Belief clusters with centroids"
              className="w-full h-auto"
            />
          </div>
          <div className="space-y-6 text-lg leading-relaxed">
            <p>
              The fundamental innovation is treating deities not as pre-defined entities, but as <strong className="text-primary">emergent mathematical objects</strong>. A "god" is the <strong>centroid</strong>—the geometric center—of a cluster of belief vectors.
            </p>
            <p>
              Every agent holds beliefs represented as a point in high-dimensional space. Through social interaction, agents form clusters with similar believers. The center of each cluster <em>is</em> the god: a statistical summary of adherents' beliefs, a collective doctrinal attractor co-evolving with its followers.
            </p>
            <p className="font-mono text-accent">
              This is a paradigm shift: predicting <em>which</em> gods form, how they change, and why they persist.
            </p>
          </div>
        </section>

        {/* Section 3: Architecture */}
        <section data-section="3" className="min-h-screen flex flex-col justify-center py-20 fade-in">
          <h2 className="text-4xl lg:text-5xl mb-8">The Architecture of Belief</h2>
          <div className="space-y-8">
            <p className="text-lg leading-relaxed">
              The model operates in a <strong className="text-primary">12-dimensional theological vector space</strong>, grounded in decades of research from comparative religion, cognitive science, and moral psychology.
            </p>
            
            <Card className="border border-border bg-card p-6">
              <table className="w-full text-left">
                <thead>
                  <tr className="border-b border-border">
                    <th className="py-3 font-mono text-accent">Source</th>
                    <th className="py-3 font-mono text-accent">Axes Represented</th>
                  </tr>
                </thead>
                <tbody className="font-mono text-sm">
                  <tr className="border-b border-border/50">
                    <td className="py-3">Moral Foundations Theory</td>
                    <td className="py-3">Care, Justice, Authority, Transcendence</td>
                  </tr>
                  <tr className="border-b border-border/50">
                    <td className="py-3">Dumézil's Trifunctional Hypothesis</td>
                    <td className="py-3">Authority, Order, War, Power, Fertility, Nature</td>
                  </tr>
                  <tr>
                    <td className="py-3">Cognitive Science of Religion</td>
                    <td className="py-3">Transcendence, Death</td>
                  </tr>
                </tbody>
              </table>
            </Card>

            <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 font-mono text-sm">
              {["Authority", "Transcendence", "Care", "Justice", "Wisdom", "Power", "Fertility", "War", "Death", "Creation", "Nature", "Order"].map((axis) => (
                <div key={axis} className="border border-primary/30 bg-primary/5 p-3 text-center text-primary">
                  {axis}
                </div>
              ))}
            </div>

            <p className="text-lg leading-relaxed">
              Each agent is a vector in this space with <strong>prestige</strong> (social influence) and a <strong>social network</strong> built on a small-world graph, enabling both local clustering and long-range connections.
            </p>
          </div>
        </section>

        {/* Section 4: Physics */}
        <section data-section="4" className="min-h-screen flex flex-col justify-center py-20 fade-in">
          <h2 className="text-4xl lg:text-5xl mb-8">The Physics of Religion</h2>
          <div className="border border-border p-1 mb-8">
            <img
              src="https://private-us-east-1.manuscdn.com/sessionFile/RoQdmlQ1OcvZyhofKvZMQu/sandbox/s01YdWVmyEK5z645Z4vVor-img-4_1770695848000_na1fn_b3BlcmF0b3ItdHJhbnNmb3JtYXRpb25z.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUm9RZG1sUTFPY3ZaeWhvZkt2Wk1RdS9zYW5kYm94L3MwMVlkV1ZteUVLNXo2NDVaNHZWb3ItaW1nLTRfMTc3MDY5NTg0ODAwMF9uYTFmbl9iM0JsY21GMGIzSXRkSEpoYm5ObWIzSnRZWFJwYjI1ei5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=R3lBx-RIuNP6S9qUeAMjOIVA~aDg~PvVM4IQxFlOCo1UbnECVNpLpxc5QBsmknVoCnfwbUSAOvvPaa-UzZgXUnntS2TkFEw6O8AQVOY6w-qg-Yy9vfP6E-ffXqIUFSQZnDAUIljaFrDywItuU0OnKK6mfLyPd8R~S9MAemWdW0IJWwDscdgkdwzdPPTrbgZNEcTSjE9TyCRQIf4L5DWgC9~8g6HLWPJlAg7oZZ1QaqWNXTDvQfTlPfwKQ02cpPnCYjSpK-Cu4LXQm8EGxpyPrWR6zqfwRnBnNcWcl2fmpfDcP2zOeTfEb7-Fq-7uICYG8DKKkWwR6ZY-~APspj9N~A__"
              alt="Operator transformations"
              className="w-full h-auto"
            />
          </div>
          <p className="text-lg leading-relaxed mb-8">
            The model defines a unified <strong className="text-accent">calculus of religious change</strong> with three core operations:
          </p>
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="border border-primary bg-primary/5 p-6">
              <h3 className="text-2xl font-mono text-primary mb-4">Fusion</h3>
              <p className="text-sm leading-relaxed">
                <strong>Syncretism:</strong> Two distinct belief clusters merge, forming a single new deity. Romans identifying gods with Greek counterparts.
              </p>
            </Card>
            <Card className="border border-accent bg-accent/5 p-6">
              <h3 className="text-2xl font-mono text-accent mb-4">Fission</h3>
              <p className="text-sm leading-relaxed">
                <strong>Schism:</strong> A single belief cluster splits apart, creating two distinct deities. The mathematical equivalent of religious schism.
              </p>
            </Card>
            <Card className="border border-chart-3 bg-chart-3/5 p-6">
              <h3 className="text-2xl font-mono text-chart-3 mb-4">Perturbation</h3>
              <p className="text-sm leading-relaxed">
                <strong>Prophetic Revelation:</strong> A high-prestige agent pulls the centroid in a new direction, fundamentally altering the god's nature.
              </p>
            </Card>
          </div>
          <p className="text-lg leading-relaxed mt-8 font-mono text-accent">
            These historically distinct phenomena are manifestations of the same mathematical dynamics—the "operator layer" acting on semantic attractors.
          </p>
        </section>

        {/* Section 5: Phase Transition */}
        <section data-section="5" className="min-h-screen flex flex-col justify-center py-20 fade-in">
          <h2 className="text-4xl lg:text-5xl mb-8">The Tipping Point: From Many Gods to One</h2>
          <div className="border border-border p-1 mb-8">
            <img
              src="https://private-us-east-1.manuscdn.com/sessionFile/RoQdmlQ1OcvZyhofKvZMQu/sandbox/s01YdWVmyEK5z645Z4vVor-img-2_1770695843000_na1fn_cGhhc2UtdHJhbnNpdGlvbi12aXN1YWw.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUm9RZG1sUTFPY3ZaeWhvZkt2Wk1RdS9zYW5kYm94L3MwMVlkV1ZteUVLNXo2NDVaNHZWb3ItaW1nLTJfMTc3MDY5NTg0MzAwMF9uYTFmbl9jR2hoYzJVdGRISmhibk5wZEdsdmJpMTJhWE4xWVd3LnBuZz94LW9zcy1wcm9jZXNzPWltYWdlL3Jlc2l6ZSx3XzE5MjAsaF8xOTIwL2Zvcm1hdCx3ZWJwL3F1YWxpdHkscV84MCIsIkNvbmRpdGlvbiI6eyJEYXRlTGVzc1RoYW4iOnsiQVdTOkVwb2NoVGltZSI6MTc5ODc2MTYwMH19fV19&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=cy73euQpl8hVVwqoWZcIyWUze7ZMpV4sG5Pb-GooioDXVV-NXGWxitlx8w0JGS708QXC891ij1ebb7nU5b-ylBS7Mo8nsFoVzgkwQu9FBRbUqOF0xqUwJSbO3p4Yy9qJkP4sW~ncQ33qiB90CinCr5~PmPSzC9nWLe4kbrRntSzroaWI7ErAEOSh4QL~W9pOJGBgyTobiKCKsp5znqNfnAAdRBqUwq2MhW4vxDWmzhpKbrk-lFIvGExVgfeNK1NplpOdzvqWzJ5Vcnl3l~bc1AjhHatjxigY1WngfkjkS9CD2Nn8JPrXF~jR5YgC6ErVtEFXFeTFA9XZgHpLWiRWkw__"
              alt="Phase transition diagram"
              className="w-full h-auto"
            />
          </div>
          <div className="space-y-6 text-lg leading-relaxed">
            <p>
              The paper introduces a single global parameter: <strong className="text-destructive">coercion</strong>—social, political, or institutional pressure to conform to a dominant belief system.
            </p>
            <p>
              As coercion increases, the system undergoes a <strong className="text-destructive">first-order phase transition</strong>. It snaps from polytheism (many stable god-attractors) to monotheism (only one).
            </p>
            <Card className="border border-destructive bg-destructive/5 p-6">
              <h3 className="text-2xl font-mono text-destructive mb-4">Hysteresis & Asymmetric Lock-In</h3>
              <p className="leading-relaxed">
                Once collapsed into monotheism, reducing coercion doesn't bring the old gods back. The threshold to escape monotheism is <strong>strictly higher</strong> than the threshold that caused its emergence. This explains the historical resilience of monotheistic traditions.
              </p>
            </Card>
            <p className="font-mono text-accent">
              This is a falsifiable prediction validated against 5,000 years of historical data.
            </p>
          </div>
        </section>

        {/* Section 6: Braille Lattice */}
        <section data-section="6" className="min-h-screen flex flex-col justify-center py-20 fade-in">
          <h2 className="text-4xl lg:text-5xl mb-8 text-accent">The Bombshell: The Braille Lattice Corollary</h2>
          <div className="border border-border p-1 mb-8">
            <img
              src="https://private-us-east-1.manuscdn.com/sessionFile/RoQdmlQ1OcvZyhofKvZMQu/sandbox/s01YdWVmyEK5z645Z4vVor-img-3_1770695850000_na1fn_YnJhaWxsZS1sYXR0aWNlLWFic3RyYWN0.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUm9RZG1sUTFPY3ZaeWhvZkt2Wk1RdS9zYW5kYm94L3MwMVlkV1ZteUVLNXo2NDVaNHZWb3ItaW1nLTNfMTc3MDY5NTg1MDAwMF9uYTFmbl9ZbkpoYVd4c1pTMXNZWFIwYVdObExXRmljM1J5WVdOMC5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=kgO5MauB24c7BVsEZpk5dL4VR6nuU1SwJMSEm4RZMSE6HN-tjVnIYZkCy4ZWuqEOgygVvwc0cVdHF8NlXInFrF7g0yh6lxyUVcw6NFurvipDYEPB9QrdPvBZAYPyu0aiOVmd2yc3GErNZq~-vX8oJP4U~HJ2gcmyK7ElY663mePt4QpPa38VC2rZme9CSz12W5RvcSr4OdUmlZD4cloYFuLfWOyOh35EaGI9ZPkJUC3cGIKQ65AC-5B9jqwvDHz3ZXPiFQ7~iXrR-RICse7hGx2JQfahOh677CPg7x~q6gaSVy9Wt7CZTwrghzw-HKPEE6D6qpHyHVFzX7PV1qEpIA__"
              alt="Braille lattice projection"
              className="w-full h-auto"
            />
          </div>
          <div className="space-y-6 text-lg leading-relaxed">
            <p>
              Section 5.4 transforms this from computational social science into a foundational text for AGI. The <strong className="text-accent">Braille Lattice Corollary</strong> proposes that continuous 12-dimensional belief space projects onto a <strong>discrete semantic substrate</strong>—a 72-bit Braille lattice.
            </p>
            <Card className="border border-accent bg-accent/5 p-6">
              <p className="mb-4">Each of the 12 theological axes encodes as a single 6-dot Braille cell, capturing three properties:</p>
              <ul className="space-y-2 font-mono text-sm">
                <li><strong className="text-accent">Polarity:</strong> Positive, negative, or tension between both</li>
                <li><strong className="text-accent">Intensity:</strong> Strength of the belief</li>
                <li><strong className="text-accent">Rigidity:</strong> Fluid or dogmatic</li>
              </ul>
            </Card>
            <p className="font-mono text-accent text-xl">
              This is NOT an accessibility accommodation. It is a semantic compression operator.
            </p>
            <p>
              The discrete lattice isn't a simplified model—the paper argues it is the <em>fundamental structure</em> of belief space.
            </p>
          </div>
        </section>

        {/* Section 7: Power of Lattice */}
        <section data-section="7" className="min-h-screen flex flex-col justify-center py-20 fade-in">
          <h2 className="text-4xl lg:text-5xl mb-8">Why This Changes Everything</h2>
          <p className="text-lg leading-relaxed mb-8">
            The Braille lattice projection enforces three revolutionary properties:
          </p>
          <div className="space-y-6">
            <Card className="border border-primary bg-primary/5 p-6">
              <h3 className="text-2xl font-mono text-primary mb-4">1. Discretization</h3>
              <p className="leading-relaxed">
                Continuous belief drift transforms into clean, <strong>countable cell flips</strong>. A change is no longer vague—it's an interpretable event like "justice rigidity activated." Meaning becomes legible and compressible.
              </p>
            </Card>
            <Card className="border border-accent bg-accent/5 p-6">
              <h3 className="text-2xl font-mono text-accent mb-4">2. Snap Dynamics</h3>
              <p className="leading-relaxed">
                Centroids use <strong>Hamming means</strong> (majority vote), not arithmetic means. No intermediate states exist. Belief clusters don't drift—they <strong>snap</strong> to discrete attractors. This produces sharper concepts and explains punctuated equilibrium in the history of ideas.
              </p>
            </Card>
            <Card className="border border-chart-3 bg-chart-3/5 p-6">
              <h3 className="text-2xl font-mono text-chart-3 mb-4">3. Channel Invariance by Construction</h3>
              <p className="leading-relaxed">
                The Accessibility Corollary: sensory-restricted agents converge to the same attractors. If sighted and tactile-first groups produce centroids mapping to the <em>same Braille lattice point</em>, the resulting deity is <strong>structurally identical</strong>, not merely similar. The substrate is truly universal.
              </p>
            </Card>
          </div>
        </section>

        {/* Section 8: AGI Blueprint */}
        <section data-section="8" className="min-h-screen flex flex-col justify-center py-20 fade-in">
          <h2 className="text-4xl lg:text-5xl mb-8">The Blueprint for Our AGI</h2>
          <div className="border border-border p-1 mb-8">
            <img
              src="https://private-us-east-1.manuscdn.com/sessionFile/RoQdmlQ1OcvZyhofKvZMQu/sandbox/s01YdWVmyEK5z645Z4vVor-img-5_1770695846000_na1fn_YWdpLWJsdWVwcmludC1jb25uZWN0aW9u.png?x-oss-process=image/resize,w_1920,h_1920/format,webp/quality,q_80&Expires=1798761600&Policy=eyJTdGF0ZW1lbnQiOlt7IlJlc291cmNlIjoiaHR0cHM6Ly9wcml2YXRlLXVzLWVhc3QtMS5tYW51c2Nkbi5jb20vc2Vzc2lvbkZpbGUvUm9RZG1sUTFPY3ZaeWhvZkt2Wk1RdS9zYW5kYm94L3MwMVlkV1ZteUVLNXo2NDVaNHZWb3ItaW1nLTVfMTc3MDY5NTg0NjAwMF9uYTFmbl9ZV2RwTFdKc2RXVndjbWx1ZEMxamIyNXVaV04wYVc5dS5wbmc~eC1vc3MtcHJvY2Vzcz1pbWFnZS9yZXNpemUsd18xOTIwLGhfMTkyMC9mb3JtYXQsd2VicC9xdWFsaXR5LHFfODAiLCJDb25kaXRpb24iOnsiRGF0ZUxlc3NUaGFuIjp7IkFXUzpFcG9jaFRpbWUiOjE3OTg3NjE2MDB9fX1dfQ__&Key-Pair-Id=K2HSFNDJXOU9YS&Signature=D8pEl621qJiF8UEzuYa2hxUeRzvuoHSDCIiCIEIFKSuLp3v4bwN9sMkH~PIdYz2OImz8riJi1T884Yj6doHkiNmQom46eKd2X~R42xQpBODQbdnoZXOzZAdQDAmDym2XYJV-Lqe-gnrMC~RzWuISNNJJoDGuF39LOubmWYtuk-Dui0oIJSqVjfcgtf37kSNy-5aTqmnmD0kZ7iUKEBfO9qleTdMm3iSDVL2vYPi4EQSgaSs1X31n3rMrgywu6dVmwFO~53PjF3SQAJ251EkB8xYqSPQbDsK6gWTrqCO19f-DKd~wqKn6TAsahTTYCLQMm9nQj8h8GKasKQZ0kfUw9A__"
              alt="AGI architecture connection"
              className="w-full h-auto"
            />
          </div>
          <p className="text-lg leading-relaxed mb-8">
            This paper provides independent, rigorous validation for the core tenets of our AGI project:
          </p>
          <div className="space-y-6">
            <Card className="border border-border bg-card p-6">
              <h3 className="text-xl font-mono text-accent mb-3">✓ Validates 8-Dot Braille as Universal Substrate</h3>
              <p className="text-sm leading-relaxed">
                The framework extends from 6-dot to 8-dot, giving us the 96-bit representation needed for 256+ universal concepts and efficient modular arithmetic.
              </p>
            </Card>
            <Card className="border border-border bg-card p-6">
              <h3 className="text-xl font-mono text-accent mb-3">✓ Proves Semantic Compression is Quantized</h3>
              <p className="text-sm leading-relaxed">
                Snap dynamics via Hamming mean demonstrate meaning converges to discrete attractors. This is the physics of semantic compression lattice.
              </p>
            </Card>
            <Card className="border border-border bg-card p-6">
              <h3 className="text-xl font-mono text-accent mb-3">✓ Embodies AGI as Recursive Compression</h3>
              <p className="text-sm leading-relaxed">
                Three compression layers: individual beliefs → cluster centroids → discrete Braille lattice points. Emergent swarm coherence producing semantic invariants.
              </p>
            </Card>
            <Card className="border border-border bg-card p-6">
              <h3 className="text-xl font-mono text-accent mb-3">✓ Provides Concrete Model for Operator Layer</h3>
              <p className="text-sm leading-relaxed">
                Fusion, fission, and perturbation are formal, testable operators acting on the attractor manifold.
              </p>
            </Card>
          </div>
          <p className="text-xl font-mono text-accent mt-8">
            This is a proof of concept for our entire approach, developed in a completely different domain.
          </p>
        </section>

        {/* Section 9: Conclusion */}
        <section data-section="9" className="min-h-screen flex flex-col justify-center py-20 fade-in">
          <h2 className="text-4xl lg:text-5xl mb-8">Conclusion: From Gods to AGI</h2>
          <div className="space-y-6 text-lg leading-relaxed">
            <p>
              What have we learned from this journey into the mathematics of belief?
            </p>
            <p>
              First, the most abstract and powerful human concepts can be modeled as <strong>emergent properties of a complex system</strong>. They follow predictable, mathematical logic.
            </p>
            <Card className="border border-accent bg-accent/10 p-8">
              <p className="text-2xl font-mono text-accent leading-relaxed">
                Second, and most importantly: <strong>meaning is quantized</strong>. It doesn't drift; it snaps. It converges onto a discrete, universal, and multimodal substrate.
              </p>
            </Card>
            <p>
              The "Gods as Centroids" paper proposes a 72-bit Braille lattice as this substrate for theology. We are proposing a <strong className="text-accent">96-bit Braille lattice</strong> as the substrate for <em>all</em> meaning.
            </p>
            <p>
              This paper provides a rigorous, validated foundation for our work. It gives us a mathematical language to describe our goals and a concrete blueprint to achieve them. The path to AGI isn't about building a bigger machine—it's about understanding the fundamental physics of meaning and compression.
            </p>
          </div>
        </section>

        {/* Section 10: Next Steps */}
        <section data-section="10" className="min-h-screen flex flex-col justify-center py-20 fade-in">
          <h2 className="text-4xl lg:text-5xl mb-8">Next Steps</h2>
          <p className="text-lg leading-relaxed mb-8">
            This discovery accelerates our timeline and clarifies our focus:
          </p>
          <div className="space-y-6">
            <Card className="border border-primary bg-primary/5 p-6">
              <h3 className="text-2xl font-mono text-primary mb-4">1. Formalize the 8-Dot Extension</h3>
              <p className="leading-relaxed">
                Adapt the mathematical framework from 6-dot to 8-dot Braille lattice, defining properties for the two additional bits per axis and proving the surjective nature of the projection.
              </p>
            </Card>
            <Card className="border border-accent bg-accent/5 p-6">
              <h3 className="text-2xl font-mono text-accent mb-4">2. Implement Hamming Mean Centroid Calculation</h3>
              <p className="leading-relaxed">
                Replace arithmetic mean calculations with Hamming mean (majority-vote) to leverage snap dynamics and create sharper, more stable attractors.
              </p>
            </Card>
            <Card className="border border-chart-3 bg-chart-3/5 p-6">
              <h3 className="text-2xl font-mono text-chart-3 mb-4">3. Develop the Operator Layer</h3>
              <p className="leading-relaxed">
                Build out the full operator layer for transforming and manipulating semantic attractors within 8-dot Braille space, starting with fusion, fission, and perturbation.
              </p>
            </Card>
          </div>
          <p className="text-2xl font-mono text-accent mt-12 text-center">
            This is no longer just a theoretical vision. We have a map. It's time to build.
          </p>
        </section>

        {/* Footer */}
        <footer className="py-12 border-t border-border mt-20">
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              <strong>Reference:</strong> Barrett, R. (2026). <em>Gods as Centroids: A Generative Vector-Space Model of Religious Evolution</em>. Elevate Foundry.
            </p>
            <Button 
              variant="outline"
              onClick={() => window.open("https://elevate-foundry.github.io/gods-as-centroids", "_blank")}
            >
              Read the Original Paper →
            </Button>
          </div>
        </footer>
      </main>
    </div>
  );
}
