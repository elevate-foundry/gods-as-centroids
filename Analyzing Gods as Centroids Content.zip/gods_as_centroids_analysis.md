# Gods as Centroids - Analysis Notes

## Document Metadata
- **Title**: Gods as Centroids: A Generative Vector-Space Model of Religious Evolution
- **Author**: Ryan Barrett
- **Year**: 2026
- **URL**: https://elevate-foundry.github.io/gods-as-centroids

## Core Thesis
The paper presents a computational model where **deities emerge as mathematical centroids of belief-vector clusters**. Agents carry belief vectors in a 12-dimensional theological space, and through social interaction, they self-organize into clusters whose centroids represent "godforms" - collective doctrinal attractors.

## Key Concepts

### 1. Deities as Emergent Mathematical Objects
- Gods are not pre-defined entities but **statistical summaries** of adherent beliefs
- They exist as centroids (mathematical centers) of belief-vector clusters
- They co-evolve with their adherents through dynamic interaction

### 2. 12-Dimensional Theological Vector Space
The belief space consists of 12 axes grounded in comparative religion and cognitive science:
- **authority, transcendence, care, justice, wisdom, power, fertility, war, death, creation, nature, order**

Theoretical grounding:
- Moral Foundations Theory (Haidt 2012)
- Dumézil's trifunctional hypothesis (1958)
- Cognitive Science of Religion (Boyer 2001; Barrett 2004)

### 3. Agent-Based Model Components
Each agent is defined by:
- **Belief vector** (b_i): normalized position in 12D space
- **Prestige weight** (w_i): social influence factor
- **Social neighborhood** (S_i): connections via Watts-Strogatz small-world graph

**Affinity** between agents = cosine similarity of belief vectors

### 4. Three Centroid Operations (Calculus of Religious Change)
- **Fusion**: syncretism (merging of traditions)
- **Fission**: schism (splitting of traditions)
- **Perturbation**: prophetic revelation (sudden shifts)

### 5. Phase Transition: Polytheism → Monotheism
- Driven by a single **coercion parameter**
- First-order phase transition from multi-attractor (polytheistic) to single-attractor (monotheistic) regimes
- **Hysteresis**: reducing coercion does NOT restore polytheism - explains historical resilience of monotheistic traditions
- Asymmetric: easier to enter monotheism than to escape it

### 6. Historical Validation
- Model validated against 5,000 years of historical religious diversity data
- Uses quantitative databases like Seshat (Turchin et al. 2015)

### 7. Novel Falsifiable Corollaries

#### Accessibility Corollary
Sensory-restricted agents (e.g., blind/deaf) converge to the **same centroid attractors** as unrestricted agents - suggests belief convergence is independent of sensory modality

#### Asymmetric Lock-In Hypothesis
The coercion threshold for **monotheistic collapse is strictly lower** than the threshold required to **escape** it - predicts historical irreversibility

## Deity Priors (Historical Examples)
The model includes 12 historical deity priors spanning major traditions:
- **Zeus**: authority, power, order (Greek)
- **Odin**: wisdom, war, death (Norse)
- **Amun-Ra**: transcendence, creation, authority (Egyptian)
- **Ishtar**: fertility, war, power (Mesopotamian)
- **Yahweh**: authority, justice, transcendence (Abrahamic)
- **Shiva**: death, creation, transcendence (Hindu)
- **Apollo**: wisdom, order, creation (Greek)
- **Freya**: fertility, nature, care (Norse)
- **Marduk**: authority, creation, order (Babylonian)
- **Baal**: fertility, war, power (Canaanite)
- **Manitou**: nature, transcendence, wisdom (Algonquian)

## Methodological Innovations

### Fills Gaps in Existing Research
- Previous ABMs tracked religiosity **levels** but not deity **formation**
- Axelrod's cultural dissemination model lacked religious semantics
- Opinion dynamics models never applied to polytheism-monotheism transition
- Nature belief-embedding paper (Bao et al. 2025) was static with no temporal dynamics

### This Model Provides
1. Deities as emergent centroids
2. Theologically grounded vector space with interpretable semantics
3. Unified calculus of religious change
4. Coercion-driven phase transition with hysteresis
5. Falsifiable predictions

## Implementation
- Interactive web simulation
- Historical backtesting capability
- Agent-based modeling framework

## Connections to Related Concepts
This model resonates with several theoretical frameworks:
- **Semantic compression**: Gods as compressed representations of distributed beliefs
- **Attractor dynamics**: Stable belief configurations in high-dimensional space
- **Emergent complexity**: Bottom-up formation of religious structures
- **Cultural evolution**: Transmission and mutation of belief vectors
- **Phase transitions in social systems**: Critical thresholds in collective behavior

## Questions for Further Analysis
1. How does the model handle religious innovation and new deity emergence?
2. What is the relationship between the 12 theological dimensions and universal semantic primitives?
3. Can the coercion parameter be empirically measured in historical contexts?
4. How do ritual and practice (vs. belief) factor into the model?
5. What is the computational complexity of the simulation?

## Detailed Model Mechanics (from page content)

### Belief Vector Normalization
All agent belief vectors are normalized to the unit sphere (||b_i|| = 1), meaning that what matters is the **direction** of belief, not its magnitude. This is consistent with semantic embedding spaces where cosine similarity is the standard metric.

### Social Network Structure
The model uses a **Watts-Strogatz small-world graph** G(N, k, p) to define agent neighborhoods. This choice captures:
- Local clustering (agents primarily interact with nearby neighbors)
- Long-range connections (occasional "bridge" connections across the network)
- Realistic social network topology

### Prestige-Weighted Influence
Agents have differential social influence through prestige weights (w_i). Higher prestige agents are more likely to be selected as "speakers" whose beliefs influence others. This models:
- Religious authority figures
- Charismatic leaders
- Institutional power dynamics

### Affinity as Cosine Similarity
The choice of cosine similarity over Euclidean distance is significant:
- Captures **orientation** of belief rather than magnitude
- Standard practice in high-dimensional semantic spaces
- Allows for meaningful comparison of belief vectors

### Bounded Belief Space
The belief space S is a bounded manifold, reflecting the **finite cognitive capacity** of human theological imagination. This is a key constraint that prevents beliefs from extending infinitely and ensures the model remains tractable and realistic.

## 5.4 The Braille Lattice Corollary - CRITICAL FINDING

### The Discrete Semantic Substrate: Braille as Lattice Projection

This is perhaps the most theoretically significant corollary. The paper proposes a **discrete semantic substrate** that makes the Accessibility Corollary not merely approximate but **structurally exact**.

### Definition 13: Braille Lattice Projection

Let **L : S → {0,1}^72** be a projection from the continuous belief space to a discrete braille lattice.

Each theological axis **a ∈ A** is encoded as a **single standard braille cell (6 dots)**, yielding a **72-bit representation** (12 axes × 6 dots per axis).

### Encoding Structure

Each braille cell encodes **three properties** of an axis:

1. **Polarity** (dots 1-3): whether the positive pole, negative pole, or both (tension) are active
2. **Intensity** (dots 4-5): quantized to four levels {00, 01, 10, 11}
3. **Rigidity** (dot 6): whether the belief on this axis is fluid or dogmatic

### This is NOT an Accessibility Accommodation

The paper explicitly states: **"This projection is not an accessibility accommodation. It is a semantic compression operator"** that enforces three structural properties:

#### 1. Discretization
Continuous centroid drift becomes **countable cell flips**. Each flip is an interpretable event:
- "justice rigidity activated"
- "transcendence polarity reversed"

#### 2. Snap Dynamics
In the braille lattice, centroids are computed as **Hamming means** (majority-vote over bit positions). Unlike arithmetic means in R^12, Hamming means **snap to discrete states**, creating:
- Sharper attractor boundaries
- More stable deity concepts
- Clearer phase transitions

#### 3. Lossless Round-Trip
The paper claims: **"We conjecture that L is surjective and that the inverse image L^-1(c) for any braille code c is a convex polytope in S."**

This means:
- Every possible braille configuration corresponds to a valid belief region
- The continuous space can be **perfectly tiled** by these regions
- **No information is lost** in the projection

### Implications for Universal Semantic Substrates

This corollary connects directly to the concept of **universal semantic primitives**:

1. **12 dimensions map to 12 braille cells** - suggesting these theological axes are fundamental
2. **72 bits total** - close to the 50-200 universal symbols range in your conceptual model
3. **8-dot braille** could extend this to 96 bits (12 axes × 8 dots), providing even richer encoding
4. **Multimodal substrate** - braille works across text, touch, and potentially voice (through phonetic encoding)

### Connection to 8-Dot Braille Strategic Goal

The paper uses **6-dot braille** (standard), but the framework naturally extends to **8-dot braille**, which would:
- Add 2 additional dots per axis (24 more bits total = 96 bits)
- Allow for more nuanced encoding of theological properties
- Align with the 256+ universal concepts constraint (if using 8-bit encoding per axis)
- Demonstrate 8-dot braille as the correct multimodal substrate

### Semantic Compression as Natural Law

The Braille Lattice corollary suggests that **belief convergence is not just statistical but structural** - the discrete lattice enforces convergence through:
- Quantization of continuous beliefs
- Majority-vote dynamics (Hamming means)
- Snap-to-grid behavior in high-dimensional space

This makes the model feel like a **"natural law"** of belief dynamics, aligning with the single-boundary semantic projector philosophy.

### Corollary 4: Braille-Enforced Stability

The paper formalizes a critical property of the discrete lattice:

**In the braille lattice, the centroid is invariant under perturbations that do not flip any cell's majority.**

Formally: if δb_i is a perturbation to agent a_i's belief such that L(b_i + δb_i) = L(b_i), then L(G_j) is unchanged.

This means **small doctrinal drift is invisible at the lattice level** — only perturbations large enough to flip a cell's majority are visible. This produces:

1. **Punctuated equilibrium naturally**: Long periods of stability (zero flips) interrupted by bursts of cell flips at phase transitions
2. **Robustness to noise**: Minor variations in individual beliefs don't affect the collective deity concept
3. **Sharper attractors**: Deities become more stable and well-defined in the discrete lattice

### Channel Invariance by Construction

The paper states: **"If two populations — one sighted, one blind, one tactile-first — produce centroids that map to the same braille lattice point, the deity is invariant to sensory modality at the resolution of the lattice."**

This is profound: the braille projection makes the Accessibility Corollary **sharper than continuous cosine similarity**. Small continuous differences either:
- **Vanish** (same cell) 
- **Become countable** (cell flip)

This binary nature eliminates the ambiguity of "approximately the same" and makes the invariance **structural** rather than statistical.

### Definition 14: Braille Centroid

The **braille centroid** of a cluster K_j is the **Hamming mean** of the projected belief vectors:

**L(G_j) = majority({L(b_i)}_{i∈K_j})**

For each bit position, the centroid takes the **majority value**. For prestige-weighted clusters, each agent's vote is weighted by w_i.

This is fundamentally different from arithmetic means in R^12:
- Arithmetic means can drift continuously
- Hamming means **snap to discrete states**
- No intermediate values exist

### Implications for Semantic Compression

The Braille Lattice framework suggests that:

1. **Semantic compression is quantized** - meaning converges to discrete attractors, not continuous regions
2. **72-bit representation** (12 axes × 6 dots) captures the essential structure of theological belief
3. **Lossless compression** - the continuous space can be perfectly tiled by braille lattice regions
4. **Universal substrate** - the same lattice works across all sensory modalities

This aligns perfectly with the concept of **semantic invariants** - a small set of discrete symbols that persist across contexts and modalities.
